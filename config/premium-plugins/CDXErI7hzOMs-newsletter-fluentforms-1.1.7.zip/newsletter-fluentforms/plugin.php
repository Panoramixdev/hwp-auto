<?php

class NewsletterFluentForms extends NewsletterFormManagerAddon {

    /**
     * @var NewsletterFluentForms
     */
    static $instance;

    function __construct($version) {
        $this->menu_title = 'Fluent Forms';
        self::$instance = $this;
        parent::__construct('fluentforms', $version, __DIR__);
    }

    function init() {
        parent::init();

        //add_action('fluentform_before_submission_confirmation', [$this, 'hook_submission'], 20, 3);
        add_action('fluentform/before_submission_confirmation', [$this, 'hook_submission'], 20, 3);

    }

    function weekly_check() {
        parent::weekly_check();
        $license_key = Newsletter::instance()->get_license_key();
        $response = wp_remote_post('https://www.thenewsletterplugin.com/wp-content/addon-check.php?k=' . rawurlencode($license_key)
                . '&a=' . rawurlencode($this->name) . '&d=' . rawurlencode(home_url()) . '&v=' . rawurlencode($this->version)
                . '&ml=' . (Newsletter::instance()->is_multilanguage() ? '1' : '0'));
    }

    /**
     *
     */
    function hook_submission($id, $data, $form) {

        $form_id = sanitize_key($form->id);

        $newsletter = Newsletter::instance();

        $logger = $this->get_logger();

        $logger->debug($data);

        $logger->debug('Form submitted');
        //$logger->debug($form);

        $form_options = $this->get_form_options($form_id);

        if (empty($form_options)) {
            $logger->debug('No configuration for form ' . $form->id);
            return;
        }

        if (!empty($form_options['newsletter']) && empty($data[$form_options['newsletter']])) {
            Newsletter\Logs::add($this->name . '-' . $form->id, 'Submission without consent');
            $logger->debug('No consent');
            return;
        }

        $logger->debug('Intercepting form data');

        $subscription = $this->get_default_subscription($form_options);

        $subscription->data->email = $data[$form_options['email']];
        $subscription->data->referrer = 'fluentforms-' . $form->id;

        $logger->debug($form_options['name']);

        if (!empty($form_options['name']) && !empty($data[$form_options['name']])) {
            if (is_array($data[$form_options['name']]) && !empty($data[$form_options['name']]['first_name'])) {
                $subscription->data->name = $newsletter->normalize_name($data[$form_options['name']]['first_name']);
            } else {
                $subscription->data->name = $newsletter->normalize_name($data[$form_options['name']]);
            }
        }

        if (!empty($form_options['surname']) && !empty($data[$form_options['surname']])) {
            if (is_array($data[$form_options['surname']]) && !empty($data[$form_options['surname']]['last_name'])) {
                $subscription->data->surname = $newsletter->normalize_name($data[$form_options['surname']]['last_name']);
            } else {
                $subscription->data->surname = $newsletter->normalize_name($data[$form_options['surname']]);
            }
        }

        // Gender
        if (!empty($form_options['gender'])) {
            $subscription->data->sex = $this->posted_data[$form_options['gender']][0];
        }

        $public_profiles = Newsletter::instance()->get_profiles_public();
        foreach ($public_profiles as $profile) {
            $id = $profile->id;
            if (empty($form_options['profile_' . $id])) {
                continue;
            }
            $form_field = $form_options['profile_' . $id];
            if (empty($data[$form_field])) {
                continue;
            }
            if (is_array($data[$form_field])) {
                //$value = $_REQUEST[$form_field][0];
            } else {
                $value = $data[$form_field];
            }

            $subscription->data->profiles['' . $id] = stripslashes($value);
        }

        $user = $this->subscribe($subscription, $form_id);
    }

    /**
     * https://fluentforms.com/docs/fluent-form-php-api/
     * @return \TNP_FormManager_Form
     */
    public function get_forms() {
        $formApi = fluentFormApi('forms');
        $atts = [
            'status' => 'all',
            'sort_column' => 'id',
            'sort_by' => 'DESC',
            'per_page' => 100,
            'page' => 1
        ];
        $result = $formApi->forms($atts, true);
        $forms = $result['data'];

        $list = [];
        foreach ($forms as $form) {

            //die();
            $tnp_form = new TNP_FormManager_Form();
            $settings = $this->get_form_options($form->id);
            $tnp_form->connected = !empty($settings['email']);
            $tnp_form->title = $form->title;
            $tnp_form->id = $form->id;
            $list[] = $tnp_form;
        }
        return $list;
    }

    public function parse_label($field) {
        if (empty($field['settings']['label'])) {
            return $field['settings']['admin_field_label'];
        }
        return $field['settings']['label'];
    }

    public function parse_field($field, $tnp_form) {
        if ($field['element'] == 'input_text') {
            $tnp_form->fields[$field['attributes']['name']] = $this->parse_label($field);
        } else if ($field['element'] == 'input_email') {
            $tnp_form->fields[$field['attributes']['name']] = $this->parse_label($field);
        } else if ($field['element'] == 'input_name') {
            $tnp_form->fields[$field['attributes']['name']] = $this->parse_label($field);
            //$tnp_form->fields[$form_field['attributes']['name'] . '.first_name'] = $form_field['fields']['first_name']['settings']['label'];
            //$tnp_form->fields[$form_field['attributes']['name'] . '.last_name'] = $form_field['fields']['last_name']['settings']['label'];
        } else if ($field['element'] == 'input_checkbox') {
            $tnp_form->fields[$field['attributes']['name']] = $this->parse_label($field);
        }
    }

    public function get_form($form_id) {
        $formApi = fluentFormApi('forms');
        $tnp_form = new TNP_FormManager_Form();
        $form = $formApi->form($form_id);
        $form_fields = $form->fields();

        $form_fields = $form_fields['fields'];

        // Life is hard, here!
        foreach ($form_fields as $form_field) {
            if ($form_field['element'] == 'input_text') {
                $this->parse_field($form_field, $tnp_form);
            } else if ($form_field['element'] == 'input_email') {
                $this->parse_field($form_field, $tnp_form);
            } else if ($form_field['element'] == 'input_name') {
                $this->parse_field($form_field, $tnp_form);
            } else if ($form_field['element'] == 'input_checkbox') {
                $this->parse_field($form_field, $tnp_form);
            } else if ($form_field['element'] == 'container') {
                foreach ($form_field['columns'] as $column) {
                    foreach ($column['fields'] as $sub_field) {
                        $this->parse_field($sub_field, $tnp_form);
                    }
                }
            } else {
                continue;
            }
        }

        $tnp_form->title = $form->title;
        $tnp_form->id = $form_id;

        return $tnp_form;
    }
}
