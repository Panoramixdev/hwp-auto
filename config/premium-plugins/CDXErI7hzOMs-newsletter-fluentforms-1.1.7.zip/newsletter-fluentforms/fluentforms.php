<?php

/*
  Plugin Name: Newsletter - Fluent Forms Integration
  Plugin URI: https://www.thenewsletterplugin.com/documentation/addons/integrations/fluent-forms-extension/
  Description: Adds subscription option to Fluent Forms
  Version: 1.1.7
  Requires PHP: 7.0
  Requires at least: 5.6
  Author: The Newsletter Team
  Author URI: https://www.thenewsletterplugin.com
  Disclaimer: Use at your own risk. No warranty expressed or implied is provided.
 */

add_action('newsletter_loaded', function ($version) {
    if (version_compare($version, '8.5.6') < 0) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>Newsletter plugin upgrade required by <strong>Newsletter - Fluent Forms Addon</strong>.</p></div>';
        });
    } elseif (!function_exists('fluentFormApi')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>The Fluent Forms plugin is required by <strong>Newsletter - Fluent Forms Addon</strong>.</p></div>';
        });
    } else {
        include_once __DIR__ . '/plugin.php';
        new NewsletterFluentForms('1.1.7');
    }
});
