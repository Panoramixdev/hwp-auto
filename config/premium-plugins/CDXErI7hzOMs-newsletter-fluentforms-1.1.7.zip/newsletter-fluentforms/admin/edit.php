<?php
/* @var $this NewsletterFluentForms */
/* @var $controls NewsletterControls */
/* @var $form TNP_FormManager_Form */

defined('ABSPATH') || exit;

if (!$controls->is_action()) {
    $controls->data = $this->get_form_options($form->id);
} else {
    if ($controls->is_action('save')) {
        $this->save_form_options($form->id, $controls->data);
        $controls->add_toast_saved();
    }
}
?>

<div class="wrap" id="tnp-wrap">
    <?php include NEWSLETTER_ADMIN_HEADER; ?>
    <div id="tnp-heading">
        <?php $controls->title_help('/addons/integrations/fluent-forms-extension/') ?>
        <h2><?php echo esc_html($form->title) ?></h2>
        <?php include __DIR__ . '/nav.php' ?>

    </div>

    <div id="tnp-body">
        <?php $controls->show(); ?>
        <form action="" method="post">

            <?php $controls->init(); ?>
            <?php $controls->hidden('welcome_email_id'); ?>
            <?php $controls->hidden('welcome_email'); ?>



            <table class="form-table">
                <tr valign="top">
                    <th><?php esc_html_e('Opt-in', 'newsletter') ?></th>
                    <td>
                        <?php $controls->select('status', array('' => 'Default', 'double' => 'Double opt-in', 'single' => 'Single opt-in')); ?>
                        <p class="description">
                            Double opt-in asks for subscription confirmation with an activation email.
                        </p>
                    </td>
                </tr>
                <tr valign="top">
                    <th><?php esc_html_e('Email', 'newsletter'); ?></th>
                    <td>
                        <?php $controls->select('email', $form->fields, 'Integration disabled'); ?>
                    </td>
                </tr>
                <tr valign="top">
                    <th><?php esc_html_e('Consent checkbox', 'newsletter'); ?></th>
                    <td>
                        <?php $controls->select('newsletter', $form->fields, __('None', 'newsletter')); ?>
                        <p class="description">
                            On the form use a checkbox field with a single checkbox.
                        </p>
                    </td>
                </tr>
                <tr valign="top">
                    <th><?php esc_html_e('First name', 'newsletter'); ?></th>
                    <td>
                        <?php $controls->select('name', $form->fields, __('None', 'newsletter')); ?>
                    </td>
                </tr>
                <tr valign="top">
                    <th><?php esc_html_e('Last name', 'newsletter') ?></th>
                    <td>
                        <?php $controls->select('surname', $form->fields, __('None', 'newsletter')); ?>
                    </td>
                </tr>

            </table>


            <h3><?php esc_html_e('Custom fields', 'newsletter') ?></h3>
            <p>
                <a href="?page=newsletter_subscription_customfields" target="_blank">Configure</a>
            </p>

            <?php $profiles = Newsletter::instance()->get_profiles_public(); ?>
            <table class="form-table">
                <?php foreach ($profiles as $profile) { ?>
                    <tr>
                        <th>
                            <?php echo esc_html($profile->name) ?>
                        </th>
                        <td>
                            <?php $controls->select('profile_' . $profile->id, $form->fields, 'Not present') ?>
                        </td>
                    </tr>
                <?php } ?>
            </table>



            <h3>Automatically assigned lists</h3>
            <table class="form-table">
                <tr>
                    <th style="vertical-align: top">
                        Add subscribers to these lists<br>
                        <small><a href="?page=newsletter_subscription_lists" target="_blank">Manage the lists</a></small>
                    </th>
                    <td><?php $controls->lists() ?></td>
                </tr>
            </table>

            <h3>Autoresponders</h3>
            <table class="form-table">
                <tr>
                    <th style="vertical-align: top">
                        Add subscribers to these autoresponders<br>

                    </th>
                    <td>
                        <?php if (class_exists('NewsletterAutoresponder')) { ?>
                            <?php
                            $autoresponders = NewsletterAutoresponder::instance()->get_autoresponders();
                            ?>
                            <?php
                            foreach ($autoresponders as $autoresponder) {
                                $controls->checkbox_group('autoresponders', $autoresponder->id, $autoresponder->name);
                                echo '<br>';
                            }
                            ?>
                            <p class="description">
                                If an autoresponder has in/out rules, they could be applied by the Autoresponder addon. It's recommended to
                                activate only autoresponders without rules.
                            </p>

                        <?php } else { ?>
                            The Autoresponder addon is required.
                        <?php } ?>
                    </td>
                </tr>
            </table>


            <p>
                <?php $controls->button_save(); ?>
            </p>

        </form>

    </div>

    <?php include NEWSLETTER_ADMIN_FOOTER; ?>

</div>