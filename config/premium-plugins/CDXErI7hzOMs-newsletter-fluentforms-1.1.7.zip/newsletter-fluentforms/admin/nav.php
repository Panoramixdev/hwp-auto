<?php
$p = sanitize_key(wp_unslash($_GET['page'] ?? '')); // To prevent to trigger security analysis, but not necessary
?>
<ul class="tnp-nav">
    <li class="<?php echo $_GET['page'] === ''?'active':''?>"><a href="?page=newsletter_fluentforms_index">&laquo;</a></li>
    <li class="<?php echo $_GET['page'] === 'newsletter_fluentforms_edit'?'active':''?>"><a href="?page=newsletter_fluentforms_edit&id=<?php echo $form->id?>"><?php _e('Settings', 'newsletter')?></a></li>
    <li class="<?php echo $_GET['page'] === 'newsletter_fluentforms_welcome'?'active':''?>"><a href="?page=newsletter_fluentforms_welcome&id=<?php echo $form->id?>"><?php _e('Welcome email', 'newsletter')?></a></li>
    <li class="<?php echo $p === $this->logs_page?'active':''?>"><a href="?page=<?php echo rawurlencode($this->logs_page)?>&id=<?php echo rawurlencode($form->id)?>"><?php esc_html_e('Log', 'newsletter')?></a></li>
</ul>
