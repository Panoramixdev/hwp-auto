=== Fluent Forms Addon for Newsletter ===
Tested up to: 6.7.1

== Changelog ==

= 1.1.7 =

* WP 6.7.1 check
* Added opt-in override

= 1.1.6 =

* WP 6.7 check

= 1.1.5 =

* Aligned with Newsletter 8.5.6

= 1.1.4 =

* Added logging
* Requires Fluent Form 4.3.22 or greater

= 1.1.3 =

* WP 6.6.2 check

= 1.1.2 =

* WP 6.6 check

= 1.1.1 =

* WP 6.5.5 check
* Added autoresponders

= 1.1.0 =

* Aligned with Newsletter 8.1.2

= 1.0.9 =

* Compatibility with WP 6.4.3

= 1.0.8 =

* Fix

= 1.0.7 =

* Compatibility with WP 6.4.2
* Fixed the fields extration when inside columns

= 1.0.6 =

* Compatibility with WP 6.3.2
* Added custom welcome email

= 1.0.5 =

* Compatibility with WP 6.3

= 1.0.4 =

* Compatibility with WP 6.2.2

= 1.0.3 =

* Fixed error on not configured forms

= 1.0.2 =

* Fixed subscription not recorded bug

= 1.0.1 =

* Layout fix

= 1.0.0 =

* First release

