=== AutomatorWP - Webhooks ===
Contributors: automatorwp, rubengc, eneribs, dioni00, tinocm
Tags: webhooks, automatorwp, automation, automate, trigger, action
Requires at least: 4.4
Tested up to: 6.7
Stable tag: 1.3.7
License: GNU AGPLv3
License URI:  http://www.gnu.org/licenses/agpl-3.0.html

New triggers and actions to send and receive data from webhooks

== Description ==

AutomatorWP - Webhooks adds new triggers and actions to let's you send and receive data from webhooks.

You can send and receive data from anywhere, from external applications, Zapier, Integromat or, included, from another site with this add-on installed.

Any website, application or service with support to webhooks or with a Rest API can be connected with this add-on and, in consequence, with your WordPress site!

= Triggers =

* Receive data from webhook.

= Anonymous Triggers =

* Receive data from webhook.

= Actions =

* Send data to webhook.

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the link "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Frequently Asked Questions ==

== Screenshots ==

== Frequently Asked Questions ==

= Where can I find the new triggers and actions? =

All new triggers and actions are under the AutomatorWP integration.

= Can I send and receive data from Zapier, Integromat or similar services? =

Yes, absolutely, you can completely configure each trigger or action with the request parameters of your choice.

= Can I connect with other WordPress sites? =

Yes, you can connect with any other site with AutomatorWP and this add-on installed or included with other website Rest API.

= Can I use this for my custom project? =

Yes, you can use the triggers and actions to keep a communication with your custom project such as inform your project when a WooCommerce sale is made or update a user meta when your project calls a webhook from this add-on.

For webhooks received, you have completely freedom to configure which actions will happen before (email user, update it's meta, enroll user in course, etc).

and, of course, you can connect any plugin triggers and send data on a webhook anywhere you want with the information of your choice.

== Changelog ==

= 1.3.7 =

* **Developer notes**
* Fixed typo.

= 1.3.6 =

* **Developer notes**
* New integration logo.

= 1.3.5 =

* **Improvements**
* Improved support to nested fields for action tags.

= 1.3.4 =

* **Improvements**
* Added support to nested fields for action tags.

= 1.3.3 =

* **Improvements**
* Added support to '\"' character in action.

= 1.3.2 =

* **Improvements**
* Added filter to customize webhook response.

= 1.3.1 =

* **Improvements**
* Required fields option for anonymous trigger.

= 1.3.0 =

* **Improvements**
* Required values for anonymous trigger.

= 1.2.9 =

* **Bug fixes**
* Fixed JSON request format to allow "\n" breaklines.

= 1.2.8 =

* **New features**
* Action tag to receive the response data from action "Send data to webhook".

= 1.2.7 =

* **Improvements**
* Improved JSON request format to allow "\n" breaklines.

= 1.2.6 =

* **Improvements**
* Improved UI for anonymous trigger.

= 1.2.5 =

* **Bug Fixes**
* Prevent PHP Notice when route is not available.

= 1.2.4 =

* **New Features**
* New Integration: Airtable.
* New Integration: KonnectzIT.
* New Integration: Make.

= 1.2.3 =

* **Bug Fixes**
* Fixed receiving content with HTML tags.

= 1.2.2 =

* **New Features**
* Added the ability to define required parameters and required values on "Receive data from webhook" trigger (logged in and anonymous).

= 1.2.1 =

* **Bug Fixes**
* Fixed the "Send test" utility in the "Send data to webhook" action.

= 1.2.0 =

* **Improvements**
* Added Integrately as separated integration for better organization.

= 1.1.9 =

* **Improvements**
* Register integrations to ensure hook priority.

= 1.1.8 =

* **Improvements**
* Added Webhooks, Zapier, Integromat, IFTTT and Notion as separated integrations for better organization.

= 1.1.7 =

* **Developer Notes**
* Added several hooks to extend the "Send data to webhook" request fields and headers.

= 1.1.6 =

* **Bug Fixes**
* Ensure to parse format when sending a test webhook from the "Send data to webhook" action.

= 1.1.5 =

* **Improvements**
* Added the HTTP version 1.1 to the "Send data to webhook" action request as default HTTP version.

= 1.1.4 =

* **Developer Notes**
* Added several hooks to allow extend the "Send data to webhook" request.

= 1.1.3 =

* **Improvements**
* Improved support for boolean, nullable and numeric values on "Send data to webhook" action.

= 1.1.2 =

* **Developer Notes**
* Make the request method and format for the "Send data to webhook" more extensible.

= 1.1.1 =

* **Developer Notes**
* Added several hooks to allow extend the "Send data to webhook" request.

= 1.1.0 =

* **Improvements**
* Correctly merge array fields like "key/0/sub".

= 1.0.9 =

* **New Features**
* Added more information about the server response on "Send data to webhooks" logs.

= 1.0.8 =

* **New Features**
* Support for AutomatorWP minimum role setting.
* **Improvements**
* Exclude generated URL fields to get cloned or imported.
* Improved support for nested parameters when sending a webhook.

= 1.0.7 =

* **New Features**
* Added support for nested parameters.

= 1.0.6 =

* **New Features**
* Added support to anonymous automations.
* New anonymous trigger: Receive data from webhook.

= 1.0.5 =

* **Improvements**
* Meet WordPress 5.5 requirements for registering new REST API endpoints.

= 1.0.4 =

* **Improvements**
* Prevent PHP notices when "Receive data from webhook" is not correctly setup
* **Developer Notes**
* Added filters to override the parameters received from a request.

= 1.0.3 =

* **New Features**
* Added support for JSON requests.
* Added the request format field on "Send data to trigger" to be able to send JSON requests.

= 1.0.2 =

* **New Features**
* Added the ability to determine the user through email on receive data from webhook trigger.
* Support for custom headers on send data to webhook action.

= 1.0.1 =

* **New Features**
* Update send request function to use the brand new parser added in AutomatorWP 1.1.0 with support to user and post metas.

= 1.0.0 =

* Initial release.
