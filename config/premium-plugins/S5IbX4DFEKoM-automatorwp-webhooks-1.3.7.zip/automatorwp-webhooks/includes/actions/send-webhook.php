<?php
/**
 * Send Webhook
 *
 * @package     AutomatorWP\Integrations\AutomatorWP\Actions\Send_Webhook
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

class AutomatorWP_Webhooks_Send_Webhook extends AutomatorWP_Integration_Action {

    /**
     * Store the action result
     *
     * @since 1.0.0
     *
     * @var bool $result
     */
    public $result = false;

    /**
     * Store the request fields
     *
     * @since 1.0.0
     *
     * @var array $request_fields
     */
    public $request_fields = array();

    /**
     * Store the request headers
     *
     * @since 1.0.0
     *
     * @var array $request_headers
     */
    public $request_headers = array();

    /**
     * The request response code
     *
     * @since 1.0.0
     *
     * @var int $response
     */
    public $response_code = 0;

    /**
     * The request response
     *
     * @since 1.0.0
     *
     * @var string $response
     */
    public $response = '';

    /**
     * The integration label
     *
     * @since 1.0.0
     *
     * @var string $label
     */
    public $label = '';

    /**
     * Initialize the action
     *
     * @since 1.0.0
     */
    public function __construct( $integration, $label ) {

        $this->integration = $integration;
        $this->action = $integration . '_send_webhook';
        $this->label = $label;

        parent::__construct();

    }

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'       => $this->integration,
            /* translators: %1$s: Integration. */
            'label'             => sprintf( __( 'Send data to %1$s', 'automatorwp-webhooks' ), $this->label ),
            /* translators: %1$s: Integration. */
            'select_option'     => sprintf( __( 'Send data to %1$s', 'automatorwp-webhooks' ), "<strong>{$this->label}</strong>" ),
            /* translators: %1$s: Integration. */
            'edit_label'        => sprintf( __( 'Send data to %1$s', 'automatorwp-webhooks' ), '{webhook}' ),
            /* translators: %1$s: Integration. */
            'log_label'         => sprintf( __( 'Send data to %1$s', 'automatorwp-webhooks' ), '{webhook}' ),
            'options'           => array(
                'webhook' => array(
                    'default' => $this->label,
                    'fields' => array(
                        'url' => array(
                            'name' => __( 'URL:', 'automatorwp-webhooks' ),
                            'type' => 'text',
                            'required' => true,
                            'default' => ''
                        ),
                        'method' => array(
                            'name' => __( 'Request Method:', 'automatorwp-webhooks' ),
                            'type' => 'select',
                            'options_cb' => 'automatorwp_webhooks_get_request_methods',
                            'default' => 'POST'
                        ),
                        'format' => array(
                            'name' => __( 'Request Format:', 'automatorwp-webhooks' ),
                            'type' => 'select',
                            'options_cb' => 'automatorwp_webhooks_get_request_formats',
                            'default' => 'FORM'
                        ),
                        'fields' => array(
                            'name' => __( 'Fields:', 'automatorwp-webhooks' ),
                            'type' => 'group',
                            'classes' => 'automatorwp-fields-table',
                            'options'     => array(
                                'add_button'        => __( 'Add pair', 'automatorwp-webhooks' ),
                                'remove_button'     => '<span class="dashicons dashicons-no-alt"></span>',
                            ),
                            'fields' => array(
                                'key' => array(
                                    'name' => __( 'Key:', 'automatorwp-webhooks' ),
                                    'type' => 'text',
                                    'default' => ''
                                ),
                                'value' => array(
                                    'name' => __( 'Value:', 'automatorwp-webhooks' ),
                                    'type' => 'text',
                                    'default' => ''
                                ),
                            ),
                        ),
                        'headers' => array(
                            'name' => __( 'Headers:', 'automatorwp-webhooks' ),
                            'type' => 'group',
                            'classes' => 'automatorwp-fields-table',
                            'options'     => array(
                                'add_button'        => __( 'Add pair', 'automatorwp-webhooks' ),
                                'remove_button'     => '<span class="dashicons dashicons-no-alt"></span>',
                            ),
                            'fields' => array(
                                'key' => array(
                                    'name' => __( 'Key:', 'automatorwp-webhooks' ),
                                    'type' => 'text',
                                    'default' => ''
                                ),
                                'value' => array(
                                    'name' => __( 'Value:', 'automatorwp-webhooks' ),
                                    'type' => 'text',
                                    'default' => ''
                                ),
                            ),
                        ),
                    )
                )
            ),
            'tags' => automatorwp_webhooks_get_actions_response_tags()
        ) );

    }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Send data button
        add_filter( 'automatorwp_automation_ui_before_option_form', array( $this, 'before_option_form' ), 10, 5 );

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        // Dynamic action tags replacements
        add_filter( 'automatorwp_action_tags_replacements', array( $this, 'dynamic_action_tags_replacements' ), 10, 4 );

        parent::hooks();
    }

    /**
     * Before option form custom content
     *
     * @since 1.0.0
     *
     * @param stdClass  $object     The trigger/action object
     * @param string    $item_type  The object type (trigger|action)
     * @param string    $option     The option key
     * @param array     $args       The option arguments
     */
    public function before_option_form( $object, $item_type, $option, $args ) {

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return;
        }

        ?>
        <div class="automatorwp-webhook-send-test-response"></div>
        <button type="button" class="button automatorwp-webhooks-send-test"><?php _e( 'Send Test', 'automatorwp-webhooks' ); ?></button>
        <div class="clear" style="margin-bottom: 15px;"></div>
        <?php

    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        // Shorthand
        $url        = $action_options['url'];
        $method     = $action_options['method'];
        $format     = $action_options['format'];
        $fields     = $action_options['fields'];
        $headers    = $action_options['headers'];

        // Setup request fields
        $this->request_fields = array();

        if( is_array( $fields ) ) {

            // Turn array( 'key' => '', 'value' => '' ) into array( 'key' => 'value' )
            foreach( $fields as $field ) {

                // Parse tags replacements to both, key and value
                $key = automatorwp_parse_automation_tags( $automation->id, $user_id, $field['key'] );
                $value = automatorwp_parse_automation_tags( $automation->id, $user_id, $field['value'] );

                // Can't sent empty field key
                if( empty( $key ) ) {
                    continue;
                }

                // TODO: Remove in AutomatorWP 3.0, Check for backward compatibility
                if( function_exists( 'automatorwp_parse_function_arg_value' ) ) {
                    // Parse values like "null", "true" or "12" to their correct value types
                    $value = automatorwp_parse_function_arg_value( $value );
                }

                // Check if field already exists
                if( isset( $this->request_fields[$key] ) ) {

                    // Ensure that field is an array
                    if( ! is_array( $this->request_fields[$key] ) ) {
                        $this->request_fields[$key] = array( $this->request_fields[$key] );
                    }

                    $this->request_fields[$key][] = $value;

                } else {
                    $this->request_fields[$key] = $value;
                }


            }

        }

        /**
         * Available filter to override the request fields without key parsed (keys still as key/sub_key)
         *
         * @since 1.0.0
         *
         * @param array                                 $request_fields     The request fields (keys still as key/sub_key)
         * @param stdClass                              $action             The action object
         * @param int                                   $user_id            The user ID
         * @param array                                 $action_options     The action's stored options (with tags already passed)
         * @param stdClass                              $automation         The action's automation object
         * @param AutomatorWP_Webhooks_Send_Webhook  $send_webhook       The send webhook object
         */
        $this->request_fields = apply_filters( 'automatorwp_webhooks_send_webhook_request_fields', $this->request_fields, $action, $user_id, $action_options, $automation, $this );

        // Turn array( 'key/sub_key' => '' ) into array( 'key' => array( 'sub_key' => ''  )  )
        foreach( $this->request_fields as $key => $value ) {

            if( strpos( $key, '/' ) === false ) {
                continue;
            }

            $keys = explode( '/', $key );

            $sub_fields = array();
            $ref = &$sub_fields;
            foreach ( $keys as $i => $v ) {
                if( $i === ( count( $keys ) - 1 ) ) {
                    $ref[$v] = $value;
                } else {
                    $ref[$v] = array();
                }

                $ref = &$ref[$v];
            }

            $this->request_fields = automatorwp_webhooks_array_merge_recursive( $this->request_fields, $sub_fields );

            unset( $this->request_fields[$key] );
        }

        /**
         * Available filter to override the request fields with key parsed (keys are key => array( sub_key ) )
         *
         * @since 1.0.0
         *
         * @param array                                 $request_fields     The request fields (keys are key => array( sub_key ) )
         * @param stdClass                              $action             The action object
         * @param int                                   $user_id            The user ID
         * @param array                                 $action_options     The action's stored options (with tags already passed)
         * @param stdClass                              $automation         The action's automation object
         * @param AutomatorWP_Webhooks_Send_Webhook  $send_webhook       The send webhook object
         */
        $this->request_fields = apply_filters( 'automatorwp_webhooks_send_webhook_request_fields_keys_passed', $this->request_fields, $action, $user_id, $action_options, $automation, $this );


        // Setup request headers
        $this->request_headers = array();

        if( is_array( $headers ) ) {

            // Turn array( 'key' => '', 'value' => '' ) into array( 'key' => 'value' )
            foreach( $headers as $header ) {

                // Parse tags replacements to both, key and value
                $key = automatorwp_parse_automation_tags( $automation->id, $user_id, $header['key'] );
                $value = automatorwp_parse_automation_tags( $automation->id, $user_id, $header['value'] );

                // Can't sent empty header key
                if( empty( $key ) ) {
                    continue;
                }

                // Headers should match the patter "{key}: {value}" like "Content-Type: text/html"
                $this->request_headers[] = $key . ': ' . $value;
            }

        }

        /**
         * Available filter to override the request headers
         *
         * @since 1.0.0
         *
         * @param array                                 $request_headers    The request headers
         * @param stdClass                              $action             The action object
         * @param int                                   $user_id            The user ID
         * @param array                                 $action_options     The action's stored options (with tags already passed)
         * @param stdClass                              $automation         The action's automation object
         * @param AutomatorWP_Webhooks_Send_Webhook  $send_webhook       The send webhook object
         */
        $this->request_headers = apply_filters( 'automatorwp_webhooks_send_webhook_request_headers', $this->request_headers, $action, $user_id, $action_options, $automation, $this );

        // Setup the request type
        if ( $method === 'POST' ) {
            $request_type = CURLOPT_POST;
        } else if ( $method === 'GET') {
            $request_type = 'GET';
        } else if ( $method === 'PUT') {
            $request_type = CURLOPT_PUT;
        } else if ( $method === '') {
            // Handle empty method
            $request_type = CURLOPT_POST;
        } else {
            // Handle custom method
            $request_type = 'CUSTOM';
        }

        // Setup the request fields
        $fields_string = http_build_query( $this->request_fields );

        // Parse the format option
        if( $format === 'JSON' && in_array( $method, array( 'POST', 'PUT' ) ) ) {
            $fields_string = json_encode( $this->request_fields );
            $fields_string = str_replace( "\\\\\\\\n", "\\n", $fields_string );
            $fields_string = str_replace( "\\\\n", "\\n", $fields_string );
			$fields_string = str_replace( '\\\"', '"', $fields_string );
            
            $this->request_headers[] = 'Content-Type: application/json';
        }

        /**
         * Available filter to modify the fields string
         *
         * @since 1.0.0
         *         
         * @param string                                $fields_string      The fields string
         * @param stdClass                              $action             The action object
         * @param int                                   $user_id            The user ID
         * @param array                                 $action_options     The action's stored options (with tags already passed)
         * @param stdClass                              $automation         The action's automation object
         * @param AutomatorWP_Webhooks_Send_Webhook  $send_webhook       The send webhook object
         */
        $fields_string = apply_filters( 'automatorwp_webhooks_send_webhook_fields_string', $fields_string, $action, $user_id, $action_options, $automation, $this );

        // Init cURL
        $ch = curl_init();

        curl_setopt( $ch, CURLOPT_URL, $url );

        // Setup the request type
        if ( $request_type === CURLOPT_POST ) {
            curl_setopt( $ch, CURLOPT_POST, 1 );
            curl_setopt( $ch, CURLOPT_POSTFIELDS, $fields_string );
        } else if ( $request_type === 'GET') {
            $url  .= '?' . $fields_string;
        } else if ( $request_type === CURLOPT_PUT ) {
            curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'PUT' );
            curl_setopt( $ch, CURLOPT_POSTFIELDS, $fields_string );
        } else if( $request_type === 'CUSTOM' ) {
            curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, $method );
            curl_setopt( $ch, CURLOPT_POSTFIELDS, $fields_string );
        }

        // Setup several options
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, TRUE );
        curl_setopt( $ch, CURLINFO_HEADER_OUT, TRUE );
        curl_setopt( $ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1 );

        if( ! empty( $this->request_headers ) ) {
            curl_setopt( $ch, CURLOPT_HTTPHEADER, $this->request_headers );
        }

        /**
         * Available hook to extend the cURL handle before execute the request
         *
         * @since 1.0.0
         *
         * @param stdClass                              $action             The action object
         * @param int                                   $user_id            The user ID
         * @param array                                 $action_options     The action's stored options (with tags already passed)
         * @param stdClass                              $automation         The action's automation object
         * @param CurlHandle                            $ch                 The cURL handle
         * @param AutomatorWP_Webhooks_Send_Webhook  $send_webhook       The send webhook object
         */
        do_action( 'automatorwp_webhooks_send_webhook_before_exec', $action, $user_id, $action_options, $automation, $ch, $this );

        // Process the server response
        $this->result           = curl_exec( $ch );
        $this->response_code    = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        $this->response         = ( $this->result ? $this->result : '' );

        /**
         * Available hook to handle the request response
         *
         * @since 1.0.0
         *
         * @param stdClass                              $response           The server response
         * @param int                                   $response_code      The server response code
         * @param stdClass                              $action             The action object
         * @param int                                   $user_id            The user ID
         * @param array                                 $action_options     The action's stored options (with tags already passed)
         * @param stdClass                              $automation         The action's automation object
         * @param CurlHandle                            $ch                 The cURL handle
         * @param AutomatorWP_Webhooks_Send_Webhook  $send_webhook       The send webhook object
         */
        do_action( 'automatorwp_webhooks_send_webhook_response', $this->result, $this->response_code, $action, $user_id, $action_options, $automation, $ch, $this );

        // Close cURL
        curl_close( $ch );

    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        $fields = $this->request_fields;

        if( $action_options['format'] === 'JSON' ) {
            $fields = json_encode( $fields );
        }

        $log_meta['url']            = $action_options['url'];
        $log_meta['method']         = $action_options['method'];
        $log_meta['format']         = $action_options['format'];
        $log_meta['fields']         = $fields;
        $log_meta['headers']        = $this->request_headers;
        $log_meta['response_code']  = $this->response_code;
        $log_meta['response']       = $this->response;
        $log_meta['result']         = ( $this->result ? __( 'Success', 'automatorwp-webhooks' ) : __( 'No response received', 'automatorwp-webhooks' ) );

        return $log_meta;

    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['request_info'] = array(
            'name' => __( 'Sending Information', 'automatorwp-webhooks' ),
            'desc' => __( 'Information about request sent.', 'automatorwp-webhooks' ),
            'type' => 'title',
        );

        $log_fields['url'] = array(
            'name' => __( 'URL:', 'automatorwp-webhooks' ),
            'desc' => __( 'URL of the request.', 'automatorwp-webhooks' ),
            'type' => 'text',
        );

        $log_fields['method'] = array(
            'name' => __( 'Method:', 'automatorwp-webhooks' ),
            'desc' => __( 'HTTP method of the request.', 'automatorwp-webhooks' ),
            'type' => 'text',
        );

        $log_fields['format'] = array(
            'name' => __( 'Format:', 'automatorwp-webhooks' ),
            'desc' => __( 'Request format.', 'automatorwp-webhooks' ),
            'type' => 'text',
        );

        $log_fields['fields'] = array(
            'name' => __( 'Fields:', 'automatorwp-webhooks' ),
            'desc' => __( 'Data sent on the request.', 'automatorwp-webhooks' ),
            'type' => 'text',
        );

        $log_fields['headers'] = array(
            'name' => __( 'Headers:', 'automatorwp-webhooks' ),
            'desc' => __( 'Custom headers sent on the request.', 'automatorwp-webhooks' ),
            'type' => 'text',
        );

        $log_fields['response_code'] = array(
            'name' => __( 'Response code:', 'automatorwp-webhooks' ),
            'desc' => __( 'Response code received from server.', 'automatorwp-webhooks' ),
            'type' => 'text',
        );

        $log_fields['response'] = array(
            'name' => __( 'Response:', 'automatorwp-webhooks' ),
            'desc' => __( 'Response received from server.', 'automatorwp-webhooks' ),
            'type' => 'text',
        );

        $log_fields['result'] = array(
            'name' => __( 'Request result:', 'automatorwp-webhooks' ),
            'type' => 'text',
        );

        return $log_fields;

    }

    /**
     * Setup action dynamic tags replacements
     *
     * @since 1.0.0
     *
     * @param array     $replacements   The trigger replacements
     * @param stdClass  $action        The trigger object
     * @param int       $user_id        The user ID
     * @param stdClass  $log            The last trigger log object
     *
     * @return array
     */
    function dynamic_action_tags_replacements( $replacements, $action, $user_id, $log ) {

        // Bail if action type doesn't match this action
        if( $action->type !== $this->action ) {
            return $replacements;
        }

        // Get fields stored on last log
        $fields = ct_get_object_meta( $log->id, 'response', true );
        $search = array( '{\"', '\"}', '\":', ':\"', ',\"', '\",' );
        $replacements = array( '{"', '"}', '":', ':"', ',"', '",' );
        $fields = str_replace( $search, $replacements, $fields );	
        $fields = json_decode( $fields, true );

        if( is_array( $fields ) ) {
            
            $replacements = array_merge( $replacements, automatorwp_webhooks_action_nested_fields( $fields, 'response' ) );
               
            // Append other fields values as replacements
            foreach( $fields as $key => $value ) {
                
                if ( $key !== 'response' ) {
                    $replacements[$key] = $value;
                }
                
            }
        }

        return $replacements;

    }

}