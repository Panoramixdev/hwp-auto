=== AutomatorWP - Advanced Custom Fields ===
Contributors: automatorwp, rubengc, eneribs, dioni00
Tags: advance, custom, fields, automatorwp, automation
Requires at least: 4.4
Tested up to: 6.6
Stable tag: 1.0.6
License: GNU AGPLv3
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Connect AutomatorWP with Advanced Custom Fields

== Description ==

[Advanced Custom Fields](https://wordpress.org/plugins/advanced-custom-fields/ "Advanced Custom Fields") (ACF) is the most popular custom fields solution for WordPress that lets you add, store and manage additional information to your posts and users.

= Triggers =

* User updates post field with a value.
* User updates user field with a value.
* User updates post field with a value on a post

= Actions =

* Update post field with a value.
* Update user field with a value.

= Tags =

* Updated post field name and value tags.
* Updated user field name and value tags.

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.0.6 =

* **New Features**
* New trigger: User updates post field with a value on a post.

= 1.0.5 =

* **Improvements**
* Improved the selection of fields for all types of posts.
* Trigger "User updates post field with a value" will be launched when the field value is added the first time.

= 1.0.4 =

* **Improvements**
* Improved user field selection to display those related to Users location.

= 1.0.3 =

* **Improvements**
* Custom option on post selection for "Update post field with a value" action.

= 1.0.2 =

* **Bug Fixes**
* Fixed incorrect class name.

= 1.0.1 =

* **Bug Fixes**
* Fixed tags replacement.

= 1.0.0 =

* Initial release.
