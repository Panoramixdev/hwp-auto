<?php

namespace BitApps\BTCBI_PRO\Triggers\Bricksforge;

use BitApps\BTCBI_PRO\Triggers\TriggerController;
use BitCode\FI\Flow\Flow;

final class BricksforgeController
{
    public static function info()
    {
        return [
            'name'                => 'Bricksforge',
            'title'               => __('Bricksforge', 'bit-integrations-pro'),
            'type'                => 'custom_form_submission',
            'is_active'           => true,
            'documentation_url'   => 'https://bitapps.pro/docs/bit-integrations/trigger/bricksforge-integration/',
            'tutorial_url'        => 'https://youtube.com/playlist?list=PL7c6CDwwm-AJvSYtsYiyH7O0CuV661H0s&si=F356gvJYMyckZrW_',
            'triggered_entity_id' => 'bricksforge/pro_forms/after_submit', // Form submission hook act as triggered_entity_id
            'fetch'               => [
                'action' => 'bricksforge/test',
                'method' => 'post',
            ],
            'fetch_remove' => [
                'action' => 'bricksforge/test/remove',
                'method' => 'post',
            ],
            'isPro' => true
        ];
    }

    public function getTestData()
    {
        return TriggerController::getTestData('bricksforge');
    }

    public function removeTestData($data)
    {
        return TriggerController::removeTestData($data, 'bricksforge');
    }

    public static function handleBricksforgeSubmit(...$record)
    {
        $formData = BricksforgeHelper::setFields($record[0]);

        if (get_option('btcbi_bricksforge_test') !== false) {
            update_option('btcbi_bricksforge_test', [
                'formData'   => $formData,
                'primaryKey' => [(object) ['key' => 'id', 'value' => $record[0]['formId']]]
            ]);
        }

        if ($flows = Flow::exists('Bricksforge', current_action())) {
            foreach ($flows as $flow) {
                $flowDetails = static::parseFlowDetails($flow->flow_details);

                if (!isset($flowDetails->primaryKey)) {
                    continue;
                }

                if (BricksforgeHelper::isPrimaryKeysMatch($record[0], $flowDetails)) {
                    $data = BricksforgeHelper::prepareDataForFlow($record[0]);
                    Flow::execute('Bricksforge', current_action(), $data, [$flow]);
                }
            }
        }

        return ['type' => 'success'];
    }

    private static function parseFlowDetails($flowDetails)
    {
        return \is_string($flowDetails) ? json_decode($flowDetails) : $flowDetails;
    }
}
