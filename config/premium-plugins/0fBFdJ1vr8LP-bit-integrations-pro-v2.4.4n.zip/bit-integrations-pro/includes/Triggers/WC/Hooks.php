<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BTCBI_PRO\Core\Util\Hooks;
use BitApps\BTCBI_PRO\Triggers\WC\WCHelperPro;

Hooks::filter('btcbi_woocommerce_flexible_checkout_fields', [WCHelperPro::class, 'getFlexibleCheckoutFields'], 10, 1);
Hooks::filter('btcbi_woocommerce_flexible_checkout_fields_value', [WCHelperPro::class, 'getFlexibleCheckoutFieldsValue'], 10, 1);
