<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BTCBI_PRO\Core\Util\Route;
use BitApps\BTCBI_PRO\Triggers\Bricks\BricksController;

Route::post('bricks/test', [BricksController::class, 'getTestData']);
Route::post('bricks/test/remove', [BricksController::class, 'removeTestData']);
