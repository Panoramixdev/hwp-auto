<?php

// namespace BitApps\BTCBI_PRO\Triggers\Typebot;

// use BitApps\BTCBI_PRO\Triggers\Webhook\WebhookController;

// final class TypebotController extends WebhookController
// {
//     public static function info()
//     {
//         return [
//             'name' => 'Typebot',
//             'icon_url' => 'https://ps.w.org/typebot/assets/icon-256x256.png?rev=2478769',
//             'title' => 'Collect 4x more responses with your conversational forms using Typebot.',
//             'type' => 'webhook',
//             'is_active' => true,
//         ];
//     }
// }
