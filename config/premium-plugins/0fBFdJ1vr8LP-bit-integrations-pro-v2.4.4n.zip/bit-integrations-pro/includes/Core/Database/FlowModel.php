<?php
/**
 * Provides Base Model Class
 */

namespace BitApps\BTCBI_PRO\Core\Database;

/**
 * Undocumented class
 */
class FlowModel extends Model
{
    protected static $table = 'btcbi_flow';
}
