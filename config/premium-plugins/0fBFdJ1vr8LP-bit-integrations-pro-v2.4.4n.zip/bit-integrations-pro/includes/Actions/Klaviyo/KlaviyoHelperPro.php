<?php

/**
 * Klaviyo    Record Api
 */

namespace BitApps\BTCBI_PRO\Actions\Klaviyo;

/**
 * Provide functionality for Record insert, upsert
 */
class KlaviyoHelperPro
{
    public static function setCustomProperties($requestParams, $customProperties, $fieldValues)
    {
        $properties = [];

        foreach ($customProperties as $property) {
            $triggerValue = $property->formField;
            $actionValue = $property->klaviyoFormField;

            if ($triggerValue === 'custom') {
                $properties[$actionValue] = \BitCode\FI\Core\Util\Common::replaceFieldWithValue($property->customValue, $fieldValues);
            } elseif (isset($fieldValues[$triggerValue])) {
                $properties[$actionValue] = $fieldValues[$triggerValue];
            }
        }

        if (!empty($properties)) {
            $requestParams['data']['attributes']['properties'] = $properties;
        }

        return $requestParams;
    }
}
