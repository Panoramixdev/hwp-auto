<?php

if (!defined('ABSPATH')) {
    exit;
}

use BitApps\BTCBI_PRO\Actions\Klaviyo\KlaviyoHelperPro;
use BitApps\BTCBI_PRO\Core\Util\Hooks;

Hooks::filter('btcbi_klaviyo_custom_properties', [KlaviyoHelperPro::class, 'setCustomProperties'], 10, 3);
