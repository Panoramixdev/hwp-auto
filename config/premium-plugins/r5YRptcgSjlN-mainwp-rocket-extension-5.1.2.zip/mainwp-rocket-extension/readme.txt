=== MainWP Rocket Extension ===
Plugin Name: MainWP Rocket Extension
Plugin URI: https://mainwp.com
Description: MainWP Rocket Extension combines the power of your MainWP Dashboard with the popular WP Rocket Plugin. It allows you to mange WP Rocket settings and quickly Clear and Preload cache on your child sites.
Version: 5.1.2
Author: MainWP
Author URI: https://mainwp.com

== Installation ==

1. Please install plugin "MainWP Dashboard" and active it before install MainWP Rocket Extension plugin (get the MainWP Dashboard plugin from url:https://mainwp.com/)
2. Upload the `mainwp-rocket-extension` folder to the `/wp-content/plugins/` directory
3. Activate the MainWP Rocket Extension plugin through the 'Plugins' menu in WordPress

== Screenshots ==
1. Enable or Disable extension on the "Extensions" page in the dashboard

== Changelog ==

= 5.1.2 - 2-6-2025 =
* Fixed: An issue with saving the "Delay JavaScript Execution" option.

= 5.1.1 - 12-27-2024 =
* Fixed: PHP warning caused by double constant declaration.

= 5.1 - 12-26-2024 =
* Fixed: Resolved the "Requested unknown parameter '1' for row 0, column 1" error.
* Added: Introduced a new action for clearing priority elements.
* Added: Added an option to manage inclusion and exclusion lists.
* Added: Implemented support for localization to enhance international usability.
* Updated: Improved navigation style for better user experience.
* Updated: Combined "Clear Cache" and "Preload Cache" into a single unified action, aligning with the latest WP Rocket workflow.
* Updated: Redesigned the Action element in the Updates Overview widget for a more intuitive look.
* Updated: Addressed coding standard issues identified by SonarCloud to improve code quality and maintainability.
* Removed: Removed settings no longer supported in the WP Rocket plugin.
* Removed: Eliminated the help sidebar from the extension’s main page for a cleaner interface.

= 5.0.1 - 3-1-2024 =
* Fixed: Conflict with the WP Rocket plugin

= 5.0 - 2-27-2024 =
* Updated: MainWP 5.0 compatibility

= 4.0.5 - 12-14-2022 =
* Updated: MainWP 4.3.1 compatibility

= 4.0.4 - 12-7-2022 =
* Preventative: Multiple security improvements

= 4.0.3 - 12-16-2021 =
* Updated: PHP 8 compatibility
* Updated: Compatibility with the latest WP Rocket version

= 4.0.2 - 3-18-2021 =
* Updated: Compatibility with the latest WP Rocket version

= 4.0.1.1 - 9-10-2020 =
* Updated: MainWP Dashboard 4.1 compatiblity

= 4.0.1 - 2-14-2020 =
* Fixed: issue with clearing and preloading cache on some setups
* Fixed: multiple cosmetic issues
* Added: saveState property to the sites list
* Added: colReorder property to the sites list
* Added: horizontal scroll to the sites lis

= 4.0 - 8-27-2019 =
* Updated: extension UI/UX redesign
* Updated: support for the MainWP 4.0

= 1.3 - 6-29-2018 =
* Fixed: multiple PHP warnings and notices
* Added: support for the new WP Rocket options

= 1.2 - 6-12-2017 =
* Added: new WP Rocket features
* Added: the Help tab
* Updated: support for new WP Rocket version
* Updated: general layout

= 1.1 - 6-10-2016 =
* Added: New WP Rocket features

= 1.0 - 2-17-2016 =
* Added: An auto update warning if the extension is not activated
* Added: Bulk load existing settings function
* Added: Support for WP-CLI
* Added: Function loading existing rocket setting from child site
* Updated: Refactored code to meet WordPress coding standards
* Updated: "Check for updates now" link is not vidible if extension is not activated

= 0.0.1 =
* First version
